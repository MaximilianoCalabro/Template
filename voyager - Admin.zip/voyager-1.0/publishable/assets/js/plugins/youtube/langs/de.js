tinymce.addI18n('de',{
	'Choose YouTube Video'  : 'YouTube Video suchen',
	'Insert Youtube video'  : 'Einf\u00fcgen youtube video',
	'width'					: 'Breite',
	'height'				: 'H\u00f6he',
	'skin'					: 'Skin',
	'dark'          		: 'dunkel',
	'light'         		: 'licht',
	'Search'        		: 'Suche',
	'Youtube URL'   		: 'Youtube URL',
	'Title'         		: 'Titel',
	'Insert and Close'		: 'Einf\u00fcgen und Schlie\u00dfen',
	'Insert'				: 'Einf\u00fcgen',
	'Load More'				: 'Mehr laden',
	'cancel'				: 'stornieren'
});
