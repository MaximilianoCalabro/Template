<?php

return [
	'name' => 'Email'
];