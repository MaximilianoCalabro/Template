<?php

namespace Modules\Links\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class LinksDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();


        // TODO: Redes Sociales

        // $this->call("OthersTableSeeder");
    }
}
