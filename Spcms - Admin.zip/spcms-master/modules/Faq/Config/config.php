<?php

return [
	'name' => 'Faq'
];