<?php namespace Modules\Images\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Modules\Images\Models\Album;

use Modules\Images\Http\Requests\AlbumRequest;


use Auth;

class AlbumController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$albums = Album::all();

		return view('images::albums.index', compact('albums'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return view('images::albums.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param Request $request
	 * @return Response
	 */
	public function store(AlbumRequest $request)
	{
		$album = new Album();

		$album->title = $request->input("title");

		$album->save();

		return redirect()->route('admin.imagenes.index')->withErrors(['good' => 'Album creado correctamente.']);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$album = Album::findOrFail($id);

		return view('images::albums.show', compact('album'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$album = Album::findOrFail($id);

		return view('images::albums.edit', compact('album'));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @param Request $request
	 * @return Response
	 */
	public function update(AlbumRequest $request, $id)
	{
		$album = Album::findOrFail($id);

		$album->title = $request->input("title");

		$album->save();

		return redirect()->route('admin.imagenes.index')->withErrors(['good' => 'Album actualizado correctamente.']);
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$album = Album::findOrFail($id);
		$album->delete();

		return redirect()->route('admin.imagenes.index')->withErrors(['good' => 'Album borrado correctamente.']);
	}

}
