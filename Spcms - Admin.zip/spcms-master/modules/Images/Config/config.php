<?php

return [
	'name' => 'Images'
];