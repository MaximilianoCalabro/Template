<html>
<head></head>
<body>
	<h3>{{$asunto}}</h3>
	<div style="padding: 10px;">		
		<p>{!!$mensaje!!}</p>
		<p>{!!$responder!!}</p>
	</div>
</body>
</html>