<html>
<head></head>
<body>
	<div style="padding: 10px;">	
		<p><strong>Nombre: </strong>{!!$nombre!!}<p>
		<p><strong>Email: </strong>{!!$email!!}<p>	
		<p><strong>Mensaje: </strong></p>
		<p>{!!$texto!!}<p>
	</div>
</body>
</html>