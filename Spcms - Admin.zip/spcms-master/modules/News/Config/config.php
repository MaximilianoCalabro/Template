<?php

return [
	'name' => 'News'
];