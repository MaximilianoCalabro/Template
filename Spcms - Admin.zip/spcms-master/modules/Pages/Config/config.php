<?php

return [
    'name' => 'Pages'
];
