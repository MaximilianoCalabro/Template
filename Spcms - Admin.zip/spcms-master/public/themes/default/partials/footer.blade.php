<footer>

	<strong>
		<a href="http://www.indis.com.ar" target="_blank">
			<img src="@asset('img/indis-black.png')" style="height: 25px; padding: 0px 5px">
		</a>
		Copyright &copy; 2016 - 2017
	</strong>  
	Todos los derechos reservados. <em>{!! protectEmail('info@indis.com.ar') !!}</em>

	<div class="pull-right hidden-xs" style="font-size: 1.2em;">
		Cache: {{ date('H:i:s') }}
	</div>
</footer>