<?php
/**
 * iThemer Theme Custom CSS
 *
 * @package Newspaper_Magazine
 */
if( !function_exists( 'ithemer_custom_css' ) ) :
	/*
	 * Function For Custom CSS
	 *
	 *
	 */
	function ithemer_custom_css() {
?>
		<style type="text/css">	
		#personal-area {
    		background-image: url(<?php echo( get_header_image() ); ?>);
			
		</style>
		<?php
	}
endif;
add_action( 'wp_head', 'ithemer_custom_css' );
?>