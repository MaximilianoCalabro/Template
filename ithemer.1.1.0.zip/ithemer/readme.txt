=== iThemer ===

Contributors: ithemer
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready

Requires at least: 4.0
Tested up to: 4.9
Stable tag: 1.0.3
License: GNU General Public License v2 or later
License URI: ithemer.com


== Description ==

Ithemer is Simple Blog & Portfolio Theme for Designer, Developer, Freelancer. iThemer is Multipurpose Theme for Biography and Personal Blog.


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

iThemer includes support for Jetpack.

== Changelog ==

= 1.1.0 - Nov 21 2017 =
* Change in Code and Files with CSS

= 1.0.2 - Oct 4 2017 =
* Implemented proper sanitization
* All untrusted data are properly escaped before displaying
* Menu parameter has been removed from wp_nav_menu() function
* Custom search form has been removed
* All minified files has been removed and respective unminified files are included
* Licenses for animate.css and wow.js have been included
* License of image used in screenshot has been changed
* Proper prefixing has been done

= 1.0.0 - Sep 27 2017 =
* Initial Release

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
* Font Awesome icons, Copyright Dave Gandy, License: SIL Open Font License, version 1.1 (http://fontawesome.io/)
* Jquery Easing , Copyright Â© 2008 George McGinley Smith, [BSD] http://gsgd.co.uk/sandbox/jquery/easing/
* WOW JS, Copyright (c) 2015 Matthieu Aussaguel, [MIT]
* jQuery One Page Nav Plugin, Copyright (c) 2010 Trevor Davis (http://trevordavis.net), [MIT], [GPL], http://github.com/davist11/jQuery-One-Page-Nav
* Modernizer http://modernizr.com/download/ [MIT]
* SlickNav Responsive Mobile Menu v1.0.10, (c) 2016 Josh Cope, [MIT],https://github.com/ComputerWolf/SlickNav/blob/master/MIT-LICENSE.txt
* Breadcrumbs Trail https://github.com/justintadlock/breadcrumb-trail, Copyright and License : Breadcrumb Trail is licensed under the GNU GPL, version 2 or later, 2008âââ2015 Â© Justin Tadlock.
* wp_bootstrap_navwalker, Edward McIntyre - @twittem, https://github.com/twittem/wp-bootstrap-navwalker, [GPL],ttp://www.gnu.org/licenses/gpl-2.0.txt





== Screenshot Images ==
* https://pixabay.com/en/entrepreneur-startup-start-up-man-593358/, [CC0] https://creativecommons.org/publicdomain/zero/1.0/
* https://pixabay.com/en/write-plan-business-startup-593333/, [CC0] https://creativecommons.org/publicdomain/zero/1.0/
* https://pixabay.com/en/macbook-mac-apple-ipad-iphone-577758/, [CC0] https://creativecommons.org/publicdomain/zero/1.0/
* banner-pattnern.png Self Created  [GPL]




